# 第一次作业

姓名：费伦宙
学号：1303121797

编程环境：Linux + GNU Tools chain

问题一：对外的接口放在了Fridge.h中了
				实现放在Fridge.cc中

问题二：举了一个买酒的例子，主函数中一个语句实现了三种多态,若把cout跟它合并到
				一共函数中，则实现了四种多态

##文件夹目录结构
.
├── problem1/
│   ├── Fridge.cc
│   └── Fridge.h
├── problem2/
│   ├── main.cc
│   ├── Wine.cc
│   └── Wine.h
└── README.md
